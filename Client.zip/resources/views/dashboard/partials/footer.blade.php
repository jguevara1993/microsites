<footer class="main-footer">
  <div class="pull-right hidden-xs">
  <a href="http://vgtechnology.com.ve" target="_blank">Desarrollado por VGTECHNOLOGY C.A.</a>
  </div>
  <strong>Copyright &copy; {{ date("Y") }} <a href="http://asiviajo.com" target="_blank">Asiviajo.com</a>.</strong> Version 1.0.0.
</footer>
