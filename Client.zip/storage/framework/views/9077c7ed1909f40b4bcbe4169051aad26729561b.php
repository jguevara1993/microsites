<?php $__env->startSection('title', $post->PostTitle); ?>
<?php $__env->startSection('content'); ?>
<section id="banner">

<!-- Slider -->
      <div id="main-slider" class="flexslider">
          <ul class="slides">
            <li>
              <img src="../themes/Optimus/assets/images/slides/1.jpg" alt="" />
              <div class="flex-caption">
                  <h3>Creative</h3>
        <p>We create the opportunities</p>

              </div>
            </li>
          </ul>
      </div>
<!-- end slider -->
</section>

<section id="content">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <img src="../assets/img/<?php echo e($post->post_image); ?>" class="img-responsive">
        <h1><?php echo e($post->PostTitle); ?></h1>
        <?php echo $post->post; ?>

      </div>

    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Optimus::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>