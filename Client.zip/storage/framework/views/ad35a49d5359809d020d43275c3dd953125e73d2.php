<?php $__env->startSection('title', 'Index'); ?>
<?php $__env->startSection('content'); ?>

<header id="fh5co-header" class="fh5co-cover js-fullheight" role="banner">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2 text-center">
        <div class="display-t js-fullheight">
          <div class="display-tc js-fullheight animate-box" data-animate-effect="fadeIn">
            <h1>Lorem ipsum dolor sit amet &amp; consectetur adipiscing elit</h1>
            <h2>Lorem ipsum dolor sit amet <a href="http://vgtechnology.com.ve" target="_blank">VG TECHNOLOGY</a></h2>
            <p><a class="btn btn-primary btn-lg btn-demo" href="#"></i> Link</a> <a class="btn btn-primary btn-lg btn-learn">Link</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>

<section>
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <h1><?php echo e($block->title); ?></h1>
        <p><?php echo e($block->body); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Colorize::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>