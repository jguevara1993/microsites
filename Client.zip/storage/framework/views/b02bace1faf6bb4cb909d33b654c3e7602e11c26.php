<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700,300&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="<?php echo e(Theme::asset('Inspire::css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Inspire::css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Inspire::css/animations.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Inspire::css/style.css')); ?>">



  </head>
  <body>
    <div class="scrollToTop"><i class="icon-up-open-big"></i></div>

    <?php $__env->startSection('nav'); ?>
      <?php echo $__env->make('Inspire::partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php $__env->startSection('footer'); ?>
      <?php echo $__env->make('Inspire::partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

<script src="<?php echo e(Theme::asset('Inspire::js/jquery.min.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(Theme::asset('Inspire::js/bootstrap.min.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(Theme::asset('Inspire::js/isotope.pkgd.min.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(Theme::asset('Inspire::js/jquery.backstretch.min.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(Theme::asset('Inspire::js/jquery.appear.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(Theme::asset('Inspire::js/modernizr.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(Theme::asset('Inspire::js/main.js')); ?>" charset="utf-8"></script>





  </body>
</html>
