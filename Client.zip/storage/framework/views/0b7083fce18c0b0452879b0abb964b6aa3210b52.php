<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Dark::css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Dark::css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Dark::css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Dark::css/dark.css')); ?>">

  </head>
  <body>

    <?php $__env->startSection('nav'); ?>
      <?php echo $__env->make('Clean_Dark::partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php $__env->startSection('header'); ?>
      <?php echo $__env->make('Clean_Dark::partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php $__env->startSection('footer'); ?>
      <?php echo $__env->make('Clean_Dark::partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>


    <script src="<?php echo e(Theme::asset('Clean_Dark::js/jquery-1.11.1.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Dark::js/bootstrap.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Dark::js/jquery.nicescroll.min.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Darkt::js/jquery.easing.min.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Dark::js/main.js')); ?>" charset="utf-8"></script>

  </body>
</html>
