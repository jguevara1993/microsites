<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('content'); ?>

<section class="content-header">
  <div class="row">
    <div class="col-sm-12">
      <h1>Usuarios</h1>
      <p>Lista de usuarios de asiviajo</p>
    </div>
  </div>
</section>

<section class="content">
  <div class="row">
    <div class="col-sm-12">
      <div class="box box-info">
        <div class="box-body">
          <div class="col-sm-12">
            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>