<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?> - Default Theme</title>
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
  </body>
</html>
