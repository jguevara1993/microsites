<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('content'); ?>
<div class="test">
  <h1>Test title</h1>
  <p>Test paragrahp</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>