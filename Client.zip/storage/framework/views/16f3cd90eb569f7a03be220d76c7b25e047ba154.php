<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('body-content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        

      </h1>

    </section>

    <section class="content">
    </section>
  </div>




</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>