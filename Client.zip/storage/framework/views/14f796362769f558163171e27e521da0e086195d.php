<footer>
  <div class="container-wrap">
		<footer id="fh5co-footer" role="contentinfo">
			<div class="row">
				<div class="col-md-3 fh5co-widget">
          <?php $__currentLoopData = $footer_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h4><?php echo e($footer_1->title); ?></h4>
            <?php echo $footer_1->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>
				<div class="col-md-3 col-md-push-1">
          <?php $__currentLoopData = $footer_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h4><?php echo e($footer_2->title); ?></h4>
            <?php echo $footer_2->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>

				<div class="col-md-3 col-md-push-1">
          <?php $__currentLoopData = $footer_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_3): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h4><?php echo e($footer_3->title); ?></h4>
            <?php echo $footer_3->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>

				<div class="col-md-3">
          <?php $__currentLoopData = $footer_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_4): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h4><?php echo e($footer_4->title); ?></h4>
            <?php echo $footer_4->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>

			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; Todos los derechos reservados</small>
						<small class="block">Diseñado por <a href="http://vgtechnology.com.ve" target="_blank">VG TECHNOLOGY</a> Para: <a href="http://asivijao.com" target="_blank">asiviajo.com</a></small>
					</p>
					<p>
						<ul class="fh5co-social-icons">
              <?php $__currentLoopData = $face; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $face): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<li><a href="https://facebook.com/<?php echo e($face->value); ?>"><i class="icon-facebook"></i></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php $__currentLoopData = $twit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twit): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <li><a href="https://twitter.com/<?php echo e($twit->value); ?>"><i class="icon-twitter"></i></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<li><a href="https://linkedin.com/<?php echo e($link->value); ?>"><i class="icon-linkedin"></i></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php $__currentLoopData = $inst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<li><a href="https://instagram.com/<?php echo e($inst->value); ?>"><i class="icon-instagram"></i></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

						</ul>
					</p>
				</div>
			</div>
		</footer>
	</div><!-- END container-wrap -->
</footer>
