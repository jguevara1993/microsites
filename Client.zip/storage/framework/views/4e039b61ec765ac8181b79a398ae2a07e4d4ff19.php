<footer id="footer">

  <!-- .footer start -->
  <!-- ================ -->
  <div class="footer section">
    <div class="container">
      <div class="space"></div>
      <div class="row">
        <div class="col-sm-6">
          <div class="footer-content">
            <?php $__currentLoopData = $footer_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <h4><?php echo e($footer_1->title); ?></h4>
              <?php echo $footer_1->body; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="footer-content">
            <?php $__currentLoopData = $footer_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <h4><?php echo e($footer_2->title); ?></h4>
              <?php echo $footer_2->body; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- .footer end -->

  <!-- .subfooter start -->
  <!-- ================ -->
  <div class="subfooter">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <ul class="social-links">
            <?php $__currentLoopData = $face; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $face): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li class="facebook"><a target="_blank" href="https://www.facebook.com//<?php echo e($face->value); ?>"><i class="fa fa-facebook"></i></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php $__currentLoopData = $twit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twit): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li class="twitter"><a target="_blank" href="https://twitter.com//<?php echo e($twit->value); ?>"><i class="fa fa-twitter"></i></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li class="linkedin"><a target="_blank" href="http://www.linkedin.com/<?php echo e($link->value); ?>"><i class="fa fa-linkedin"></i></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php $__currentLoopData = $inst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li class="youtube"><a target="_blank" href="http://www.instagram.com/<?php echo e($inst->value); ?>"><i class="fa fa-instagram"></i></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

          </ul>

          <p class="text-center">&copy <?php echo date('Y') ?> Desarrollado por <a target="_blank" href="http://vgtechnology.com.ve">VG TECHNOLOGY C.A.</a> Para: <a href="http://asiviajo.com">Asiviajo.com</a></p>
        </div>
      </div>
    </div>
  </div>
  <!-- .subfooter end -->

</footer>
