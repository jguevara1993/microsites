<?php $__env->startSection('title', 'Bloques'); ?>
<?php $__env->startSection('content'); ?>

<section class="content-header">
  <div class="row">
    <div class="col-sm-12">
      <?php if(session()->has('message')): ?>
      <div class="alert alert-success alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h4><i class="icon fa fa-check"></i> ¡Exito!</h4>
              <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
    <h1>Editar Tema</h1>
    <p>En esta seccion podras incluir bloques de informacion para editar tu tema.</p>

    </div>
  </div>
</section>

<section class="content">
  <div class="row">
    <div class="col-sm-6">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Index</h3>
          <div class="box-tool pull-right">
            <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
          </div>
        </div>
        <div class="box-body">
          <table class="table table-striped">
            <tr>
              <th>id</th>
              <th>Contenido</th>
              <th> </th>
            </tr>
            <?php $__currentLoopData = $indexBlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
              <td><?php echo e($item->id); ?></td>
              <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
              <td>
                <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php echo e($indexBlock->render()); ?>

          </table>
        </div>
      </div>
    </div>
    <div class="col-sm-6">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">About</h3>
          <div class="box-tool pull-right">
            <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
          </div>
        </div>
        <div class="box-body">
          <table class="table table-striped">
            <tr>
              <th>id</th>
              <th>Contenido</th>
              <th></th>
            </tr>
            <tr>
              <?php $__currentLoopData = $aboutBlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <td><?php echo e($item->id); ?></td>
              <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
              <td>
                <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php echo e($aboutBlock->render()); ?>

          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-6">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Paquetes</h3>
          <div class="box-tool pull-right">
            <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
          </div>
        </div>
        <div class="box-body">
          <table class="table table-striped">
            <tr>
              <th>id</th>
              <th>Contenido</th>
              <th></th>
            </tr>
            <?php $__currentLoopData = $promoBlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
              <td><?php echo e($item->id); ?></td>
              <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
              <td>
                <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
              </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php echo e($promoBlock->render()); ?>

          </table>
        </div>
      </div>
    </div>

    <div class="col-sm-6">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Contacto</h3>
          <div class="box-tool pull-right">
            <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
          </div>
        </div>
        <div class="box-body">
          <table class="table table-striped">
            <tr>
              <th>id</th>
              <th>Contenido</th>
              <th></th>
            </tr>
            <?php $__currentLoopData = $contactBlock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
              <td><?php echo e($item->id); ?></td>
              <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
              <td>
                <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
              </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php echo e($contactBlock->render()); ?>

          </table>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-12">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Footer</h3>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-sm-3">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Sección 1</h3>
                  <div class="box-tool pull-right">
                    <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
                  </div>
                </div>
                <div class="box-body">
                  <table class="table table-striped">
                    <tr>
                      <th>id</th>
                      <th>Contenido</th>
                      <th></th>
                    </tr>
                    <?php $__currentLoopData = $footer_1_Block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                      <td><?php echo e($item->id); ?></td>
                      <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
                      <td>
                        <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                        <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e($footer_1_Block->render()); ?>


                  </table>
                </div>
              </div>
            </div>

            <div class="col-sm-3">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Sección 2</h3>
                  <div class="box-tool pull-right">
                    <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
                  </div>

                </div>
                <div class="box-body">
                  <table class="table table-striped">
                    <tr>
                      <th>id</th>
                      <th>Contenido</th>
                      <th></th>
                    </tr>
                    <?php $__currentLoopData = $footer_2_Block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                      <td><?php echo e($item->id); ?></td>
                      <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
                      <td>
                        <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                        <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e($footer_2_Block->render()); ?>


                  </table>
                </div>
              </div>
            </div>

            <div class="col-sm-3">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Sección 3</h3>
                  <div class="box-tool pull-right">
                    <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
                  </div>
                </div>
                <div class="box-body">
                  <table class="table table-striped">
                    <tr>
                      <th>id</th>
                      <th>Contenido</th>
                      <th></th>
                    </tr>
                    <?php $__currentLoopData = $footer_3_Block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                      <td><?php echo e($item->id); ?></td>
                      <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
                      <td>
                        <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                        <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e($footer_3_Block->render()); ?>


                  </table>
                </div>
              </div>
            </div>

            <div class="col-sm-3">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Sección 4</h3>
                  <div class="box-tool pull-right">
                    <a href="<?php echo e(route('themes.create')); ?>" class="btn btn-box-tool"><i class="fa fa-plus-square-o fa-lg"></i></a>
                  </div>
                </div>
                <div class="box-body">
                  <table class="table table-striped">
                    <tr>
                      <th>id</th>
                      <th>Contenido</th>
                      <th></th>
                    </tr>
                    <?php $__currentLoopData = $footer_4_Block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                      <td><?php echo e($item->id); ?></td>
                      <td><strong><?php echo e($item->title); ?></strong><br><?php echo e(str_limit($item->body)); ?></td>
                      <td>
                        <a href="<?php echo e(route('themes.edit', ['id' => $item->id ])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                        <a href="<?php echo e(route('themes.destroy', ['id' => $item->id])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e($footer_4_Block->render()); ?>


                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<div class="row">
    <div class="col-sm-12">
      <div class="box box-info">
        <div class="box-header">
          <h3 class="box-title">Cabecera</h3>
        </div>
        <div class="box-body">

   <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target=".bs-example-modal-lg">
    Cambiar Imagen
  </button>


  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
                <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Manejador de Archivos</h4>
        </div>
        <div class="modal-body">
          <iframe src="/admin/filemanager/dialog" width="100%" height="600" style="border:none;"></iframe>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>
      </div>
    </div>
  </div>-->




        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>