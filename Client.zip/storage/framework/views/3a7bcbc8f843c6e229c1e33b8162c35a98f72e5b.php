<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="row">
      <div class="col-sm-12">
        <?php if(session()->has('messageDelete')): ?>
          <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(session()->get('messageDelete')); ?>

        </div>

        <?php elseif(session()->has('messageSuccess')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<?php echo e(session()->get('messageSuccess')); ?>

</div>

      <?php elseif(session()->has('messageEdit')): ?>
      <div class="alert alert-success alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<?php echo e(session()->get('messageEdit')); ?>

</div>
<?php endif; ?>
<h1>Blog / Entradas</h1>
<p>En este seccion puedes ver las entradas y selecionarlas para editarlas, eliminarlas o crear una nueva.</p>

  </div>
  </div>

</section>

  <section id="manage-blog" class="content">
    <div class="box box-info">
      <div class="box-body">
      <div class="row">
        <div class="col-sm-12">
          <a class="btn btn-success" href="/blog/create" role="button">Crear nuevo</a>
        </div>

        <div class="col-sm-12" id="blog-table">
            <table class="table table-striped">
                <tr>
                  <th>ID</th>
                  <th>Slug</th>
                  <th>Titulo</th>
                  <th>Post</th>
                  <th>Categorias</th>
                  <th>Etiquetas</th>
                  <th>Fecha de creación</th>
                  <th> </th>
                </tr>

              <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->slug); ?></td>
                <td><?php echo e($post->PostTitle); ?></td>
                <td class="post-title"><?php echo e($post->post); ?></td>
                <td>
                <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <p><?php echo e($category->category_name); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </td>
                <td>
                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <p><?php echo e($tag->tag); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </td>
                <td><?php echo e($post->created_at); ?></td>
                <td>
                  <a href="<?php echo e(route('blog.show', ['id' => $post->id ])); ?>" class="btn btn-info" target="_blank"><i class="fa fa-search" aria-hidden="true"></i></a>
                  <a href="<?php echo e(route('blog.edit', ['id'=> $post->id])); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                  <a href="<?php echo e(route('blog.destroy', ['id' => $post->id ])); ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </table>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>