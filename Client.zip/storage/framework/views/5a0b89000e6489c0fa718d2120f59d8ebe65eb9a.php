<footer class="main-footer">
  <div class="pull-right hidden-xs">
  <a href="#">Desarrollado por VGTECHNOLOGY C.A.</a>
  </div>
  <strong>Copyright &copy; <?php echo e(date("Y")); ?> <a href="#">Asiviajo.com</a>.</strong> All rights reserved.
</footer>
