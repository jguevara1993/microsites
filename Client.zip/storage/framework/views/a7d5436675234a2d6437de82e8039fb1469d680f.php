<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('content'); ?>

<section class="content-header">
  <div class="row">
    <div class="col-sm-12">
      <h1>Bienvenido, <small><?php echo e(Auth::user()->name); ?></small></h1>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>