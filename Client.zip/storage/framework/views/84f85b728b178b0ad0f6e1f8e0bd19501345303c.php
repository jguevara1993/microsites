<nav class="fh5co-nav" role="navigation">
  <div class="container-wrap">
    <div class="top-menu">
      <div class="row">
        <div class="col-xs-2">
          <div id="fh5co-logo"><a href="/"><?php echo e(config('app.name')); ?></a></div>
        </div>
        <div class="col-xs-10 text-right menu-1">
          <ul>
            <li><a href="/">Inicio</a></li>
            <li><a href="/about">Sobre nosotros</a></li>
            <li><a href="/promo">Paquetes</a></li>
            <li><a href="/blog">Blog</a></li>
            <li><a href="/contact">Contacto</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</nav>
