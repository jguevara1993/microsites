<footer>
  <div id="fh5co-footer" role="contentinfo">
		<div class="container">
			<div class="row">
				<div class="col-md-4 animate-box">
          <?php $__currentLoopData = $footer_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3 class="section-title"><?php echo e($footer_1->title); ?></h3>
            <?php echo $footer_1->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>

				<div class="col-md-4 animate-box">
          <?php $__currentLoopData = $footer_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3 class="section-title"><?php echo e($footer_2->title); ?></h3>
            <?php echo $footer_2->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

				</div>
				<div class="col-md-4 animate-box">
          <?php $__currentLoopData = $footer_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_3): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3 class="section-title"><?php echo e($footer_3->title); ?></h3>
            <?php echo $footer_3->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="copy-right">&copy; <?php echo date('Y') ?>	Desarrollado por: <a href="http://vgtechnology.com.ve" target="_blank">VG TECHONOLOGY</a>
						Para: <a href="http://asiviajo.com/" target="_blank">Asiviajo</a>
					</p>
				</div>
			</div>
		</div>
	</div>

</footer>
