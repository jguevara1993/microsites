<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="col-xs-12">
      <img src="../assets/img/<?php echo e($post->post_image); ?>" alt="">
      <h1><?php echo e($post->PostTitle); ?></h1>
      <p><?php echo $post->post; ?></p>
    </div>

  </body>
</html>
