<?php $__env->startSection('title', 'Sobre nosotros'); ?>
<?php $__env->startSection('content'); ?>
<section>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 scrollclass">
        <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <h1><?php echo e($block->title); ?></h1>
          <p><?php echo $block->body; ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Clean_Dark::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>