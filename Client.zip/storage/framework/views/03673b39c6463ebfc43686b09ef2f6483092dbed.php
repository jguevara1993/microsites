<footer>
  <div class="footer">
    <div class="container">
      <div class="row">
        <div class="col-footer col-md-4 col-xs-6">
          <?php $__currentLoopData = $footer_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3><?php echo e($footer_1->title); ?></h3>
            <?php echo $footer_1->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
        <div class="col-footer col-md-4 col-xs-6">
          <?php $__currentLoopData = $footer_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3><?php echo e($footer_2->title); ?></h3>
            <?php echo $footer_2->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>
        <div class="col-footer col-md-4 col-xs-6">
          <?php $__currentLoopData = $footer_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_3): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <h3><?php echo e($footer_3->title); ?></h3>
            <?php echo $footer_3->body; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>

      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="footer-copyright">&copy; <?php echo date('Y') ?> Basica Bootstrap HTML Template. Desarrollado por <a href="http://www.vgtechnology.com.ve">VG TECHNOLOGY C.A.</a> Para: <a href="http://asiviajo.com">Asiviajo.com</a></div>
        </div>
      </div>
    </div>
  </div>

</footer>
