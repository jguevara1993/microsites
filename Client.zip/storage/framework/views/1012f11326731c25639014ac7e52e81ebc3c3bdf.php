<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('content'); ?>

  <section class="content-header">
    <div class="row">
      <div class="col-sm-12">
        <?php if(session()->has('message')): ?>
          <?php echo e(session()->get('message')); ?>

        <?php endif; ?>
        <h1>Plantillas</h1>
        <p>Cambia la plantilla de tu sitio y dale un nuevo estilo</p>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="row">
      <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $themes): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-sm-4">
          <div class="box box-info">
            <div class="box-body">
              <h1><?php echo e($themes->theme_name); ?></h1>
              <img src="../themes/<?php echo e($themes->theme_name); ?>/assets/images/<?php echo e($themes->theme_image); ?>" class="img-responsive">
            </div>
              <div class="box-footer">
              <form class="" action="<?php echo e(route('themes.set')); ?>" method="POST">
              <input type="hidden" name="slug" value="<?php echo e($themes->slug); ?>">
              <button type="submit" class="btn btn-info">Aplicar</button>
              <?php echo e(csrf_field()); ?>

            </form>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>