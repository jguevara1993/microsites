<?php $__env->startSection('title', 'Sobre nosotros'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-wrap">
  <aside id="fh5co-hero">
    <div class="flexslider">
      <ul class="slides">
        <li style="background-image: url(./themes/Aurora/assets/images/img_bg_3.jpg);">
          <div class="overlay-gradient"></div>
          <div class="container-fluids">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 slider-text slider-text-bg">
                <div class="slider-text-inner text-center">
                  <h1>Lorem ipsum</h1>
                  <h2>Free html5 templates Made by <a href="http://freehtml5.co/" target="_blank">freehtml5.co</a></h2>
                </div>
              </div>
            </div>
          </div>
        </li>
        </ul>
      </div>
  </aside>

  <div id="fh5co-about">
    <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <h1><?php echo e($block->title); ?></h1>
    <p><?php echo $block->body; ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


  </div>
</div><!-- END container-wrap -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Aurora::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>