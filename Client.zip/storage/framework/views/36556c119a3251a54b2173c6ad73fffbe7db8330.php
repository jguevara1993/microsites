<?php $__env->startSection('container'); ?>
    <div class="panel panel-success">
        <div class="panel-heading">
            <h3 class="panel-title">
                <i class="glyphicon glyphicon-exclamation-sign"></i>
                <?php echo app('translator')->get('installer::installer.requirements.title'); ?>
            </h3>
        </div>
        <div class="panel-body">
            <div class="bs-component">
                <ul class="list-group">
                    <?php $__currentLoopData = $requirements['requirements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element => $enabled): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li class="list-group-item">
                        <?php if($enabled): ?>
                            <span class="badge badge-success">
                                <i class="glyphicon glyphicon-ok"></i>
                            </span>
                        <?php else: ?>
                            <span class="badge badge-danger">
                                <i class="glyphicon glyphicon-remove"></i>
                            </span>
                        <?php endif; ?>
                        <?php echo e($element); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
            <?php if(!isset($requirements['errors'])): ?>
                <a class="btn btn-success" href="<?php echo e(route('installer::permissions')); ?>">
                    <?php echo app('translator')->get('installer::installer.next'); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('installer::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>