<header>
      <div class="navbar navbar-default navbar-static-top">
          <div class="container">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="/"><?php echo e(config('app.name')); ?></a>
              </div>
              <div class="navbar-collapse collapse ">
                  <ul class="nav navbar-nav">
                      <li><a href="/">incio</a></li>
                      <li><a href="/about">Sobre nosotros</a></li>
                      <li><a href="/promo">Paquete</a></li>
                      <li><a href="/blog">Blog</a></li>
                      <li><a href="/contact">Contacto</a></li>
                  </ul>
              </div>
          </div>
      </div>
</header>
