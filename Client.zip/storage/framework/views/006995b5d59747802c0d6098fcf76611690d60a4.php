<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="themes/favicon.png" />

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,300' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="<?php echo e(Theme::asset('State::css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('State::css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('State::css/flexslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('State::css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('State::css/superfish.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('State::css/style.css')); ?>">


    </head>
    <body>
      <div id="fh5co-wrapper">
      <div id="fh5co-page">

      <?php $__env->startSection('nav'); ?>
        <?php echo $__env->make('State::partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldSection(); ?>

      <?php echo $__env->yieldContent('content'); ?>

      <?php $__env->startSection('footer'); ?>
        <?php echo $__env->make('State::partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldSection(); ?>

    </div>
  </div>


  <script src="<?php echo e(Theme::asset('State::js/jquery.min.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/jquery.easing.1.3.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/bootstrap.min.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/jquery.flexslider-min.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/sticky.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/superfish.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/jquery.waypoints.min.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/hoverIntent.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/respond.min.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/classie.js')); ?>" charset="utf-8"></script>
  <script src="<?php echo e(Theme::asset('State::js/main.js')); ?>" charset="utf-8"></script>

  </body>
</html>
