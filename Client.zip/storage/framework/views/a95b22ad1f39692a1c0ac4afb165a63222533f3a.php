<?php $__env->startSection('title', 'Index'); ?>
<?php $__env->startSection('content'); ?>

<div class="section section-breadcrumbs">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1>Blog</h1>
      </div>
    </div>
  </div>
</div>

<div class="section">
<div class="container">
<div class="row">
  <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="col-sm-6">
    <div class="blog-post blog-single-post">
      <div class="single-post-title">
        <h2><?php echo e($post->PostTitle); ?></h2>
      </div>

      <div class="single-post-image">
        <a href="<?php echo e(route('blog.show', ['id' => $post->id ])); ?>"><img src="../assets/img/<?php echo e($post->post_image); ?>" alt="Post Title"></a>
      </div>

      <div class="single-post-info">
        <i class="glyphicon glyphicon-time"></i><?php echo e($post->created_at); ?>

      </div>

      <div class="single-post-content">
        <p>
          <?php echo str_limit($post->post); ?>

        </p>
      <a href="<?php echo e(route('blog.show', ['id' => $post->id ])); ?>" class="btn">Leer Mas</a>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<div class="col-sm-12">
<?php echo $block->render(); ?>

</div>

</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Basica::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>