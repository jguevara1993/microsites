<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('body-content'); ?>

<section id="create-post">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xs-12">
        <h1>Crear Entrada</h1>
      </div>
      <div class="col-xs-12">
        <p>Aqui puedes crear tus entradas que seran mostradas en la pagina de blog</p>
      </div>

      <div class="col-sm-12">
      <form class="form-horizontal" role="form" action="<?php echo e(route('blog.store')); ?>" method="POST"  enctype="multipart/form-data">

      <div class="col-xs-8">
          <div class="form-group">
              <label for="PostTitle" class="col-sm-2 control-label">Titulo: </label>
            <div class="col-sm-10">
              <input type="text" name="PostTitle" id="PostTitle" class="form-control" placeholder="Titulo del post...">
            </div>
          </div>
          <div class="form-group">
              <label for="slug" class="col-sm-2 control-label">Slug: </label>
            <div class="col-sm-10">
              <input type="text" name="slug" id="slug" class="form-control" placeholder="Slug">
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-12">
              <textarea name="post" rows="8" id="post" cols="80" class="form-control"></textarea>
          </div>
        </div>
        <div class="col-sm-12">
          <button type="submit" class="btn btn-success" name="button">Crear</button>
          <a class="btn btn-warning" href="<?php echo e(url('blog')); ?>" role="button">Cancelar</a>

        </div>

      </div>
      <div class="col-sm-4">
        <div class="post-panel">
        </div>
        <div class="post-panel-2">
          <table class="table table-bordered">
            <tr>
              <th>Estatus: </th>
              <td>Borrador</td>

            </tr>
            <tr>
              <th>Fecha de creacion: </th>
              <td><?php echo e(date('D, d M Y H:i:s')); ?></td>

            </tr>

          </table>
        </div>
        <div class="post-panel-3">
            <div class="form-group">
              <label for="postTags">Etiquetas: </label>

              <input  type="text" name="tags[]" class="form-control" placeholder="Etiquetas" data-role="tagsinput">

            </div>
            <div class="form-group">
              <label>Categoria: </label>
              <div class="multiselect">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="checkbox"><label><input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></label></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </div>
            </div>
            <div class="form-group">
    <label for="postImage">Imagen Destacada: </label>
    <input type="file" name="postImage" id="postImage" onchange="document.getElementById('imgThumbnail').src = window.URL.createObjectURL(this.files[0]);">
    <p class="help-block">Imagen que aparecera al principio del post.</p>
    <div class="imgThumbnail">
      <img id="imgThumbnail" class="img-responsive" />
    </div>
  </div>
          <?php echo e(csrf_field()); ?>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>