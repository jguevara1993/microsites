<?php $__env->startSection('title', $post->PostTitle); ?>
<?php $__env->startSection('content'); ?>

<section>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 scrollclass">
        <img src="../assets/img/<?php echo e($post->post_image); ?>" class="img-responsive">
        <h1><?php echo e($post->PostTitle); ?></h1>
        <?php echo $post->post; ?>

      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Clean_Dark::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>