<aside class="main-sidebar">

  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">

    <!-- Sidebar user panel (optional) -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p></p>
        <!-- Status -->
      </div>
    </div>


    <!-- Sidebar Menu -->
    <ul class="sidebar-menu">
      <li class="header">Navegación</li>
      <!-- Optionally, you can add icons to the links -->
      <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-home"></i> <span>Inicio</span></a></li>
      <li><a href="#"><i class="fa fa-group"></i> <span>Clientes</span></a></li>
      <li class="treeview">
        <a href="#"><i class="fa fa-edit"></i> <span>Blog</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="/blog">Ver entradas</a></li>
          <li><a href="/blog/create">Nueva entrada</a></li>
          <li><a href="<?php echo e(url('category')); ?>">Categorias</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#"><i class="fa fa-edit"></i> <span>Usuarios</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#">Ver Usuarios</a></li>
          <li><a href="#">Agregar usuarios</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#"><i class="fa fa-edit"></i> <span>Roles</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#">Ver Roles</a></li>
          <li><a href="#">Agregar roles</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#"><i class="fa fa-edit"></i> <span>Permisos</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#">Ver Permisos</a></li>
          <li><a href="#">Agregar Permisos</a></li>
        </ul>
      </li>
      <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-remove"></i> <span>Desconectarse</span></a></li>
        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
          <?php echo e(csrf_field()); ?>

        </form>
    </ul>
    <!-- /.sidebar-menu -->
  </section>
  <!-- /.sidebar -->
</aside>
