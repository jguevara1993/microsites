<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?> | Dashboard</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/app.css')); ?>">
  <script src="<?php echo e(URL::asset('ckeditor.js')); ?>" charset="utf-8"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body class="skin-blue fixed sidebar-mini">
<div class="wrapper">
  <?php $__env->startSection('main-header'); ?>

    <?php echo $__env->make('dashboard.partials.main-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->yieldSection(); ?>

  <?php $__env->startSection('sidebar'); ?>

    <?php echo $__env->make('dashboard.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->yieldSection(); ?>


<div class="content-wrapper">
<?php echo $__env->yieldContent('body-content'); ?>
</div>


<?php $__env->startSection('footer'); ?>
<footer class="main-footer">
  <div class="pull-right hidden-xs">
  <a href="#">Desarrollado por VGTECHNOLOGY C.A.</a>
  </div>
  <strong>Copyright &copy; <?php echo e(date("Y")); ?> <a href="#">Asiviajo.com</a>.</strong> All rights reserved.
</footer>
<?php echo $__env->yieldSection(); ?>

<script src="<?php echo e(URL::asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>

</div>

</body>
</html>
