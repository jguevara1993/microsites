<?php if(isset($files["error"])): ?>

    <div class="no-data">
        <h3><?php echo e($files["error"]); ?></h3>
    </div>

<?php else: ?>

    <?php if(count($files) > 0 ): ?>

        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $file): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="item grid col-sm-3" id="item-<?php echo e($index); ?>">
            <?php if($file->type == 'dir'): ?>

                <div class="filemanager-item folder"  data-folder="<?php echo e($file->folder->path); ?>" data-name="<?php echo e($file->name); ?>">
                    <div class="row full-width centered">
                        <div class="col-sm-4 b-r b-grey icon">
                            <i class="fa fa-folder"></i>
                        </div>
                        <div class="col-sm-8 info">
                            <p><?php echo e($file->name); ?></p>
                            <?php if($file->folder->permission): ?>
                            <p class="small"> <?php echo e($file->folder->folderCount + $file->folder->fileCount); ?> item(s)</p>
                            <?php else: ?>
                                <p class="small">Without permission</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <?php if($file->can): ?>
                    <div class="filemanager-item file"  data-type="<?php echo e($file->mime); ?>" data-path="<?php echo e($file->path); ?>" data-asset="<?php echo e($file->asset); ?>" data-size="<?php echo e($file->size_human); ?>" <?php echo e(($file->mime == 'image') ? 'data-dimension='.$file->dimensions : ''); ?> >
                        <div class="row full-width centered">
                            <div class="col-sm-4 b-r b-grey icon">
                                <img src="<?php echo e($file->thumb); ?>">
                            </div>
                            <div class="col-sm-8 info">
                                <p class="name-file"><?php echo e($file->name); ?></p>
                                <p class="small"><?php echo e($file->size_human); ?></p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                        <div class="filemanager-item error-file">
                            <div class="row full-width centered">
                                <div class="col-sm-12 info">
                                    <p class="name-file"><?php echo e($file->name); ?></p>
                                    <p class="small">This file is not Readable</p>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
           <?php endif; ?>
           </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

   <?php else: ?>
       <div class="no-data">
           <h3>There is not files or folders matching your request</h3>
       </div>
   <?php endif; ?>

<?php endif; ?>