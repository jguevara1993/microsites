<?php $__env->startSection('title', 'Paquetes'); ?>
<?php $__env->startSection('content'); ?>
<div id="home-sec">
    <div class="overlay">
        <div class="container">
            <div class="col-md-8 pad-top scrollclass">

                <h1>
                    <strong>Simple way to <mark>Attract </mark>your audience by this page </strong>
                </h1>
                <p class="home-p">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Mauris sagittis felis dolor vitae. Mauris sagittis felis dolor vitae.
            Mauris sagittis felis dolor vitae Mauris sagittis felis dolor vitae.
             Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </p>
                <a class="btn btn-primary btn-lg btn-home" href="#features-sec">Explore More &nbsp; <i class="fa fa-toggle-on"></i></a>
            </div>
            <div class="col-md-4 img-home-side ">
                <img src="../themes/Clean_Light/assets/images/home-side.png" class="img-responsive" />
            </div>
        </div>
    </div>

</div>

<section>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 scrollclass">
        <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <h1><?php echo e($block->title); ?></h1>
          <p><?php echo e($block->body); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Clean_Dark::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>