<footer id="location-sec">
    <div class="container">
        <div class="row text-center min-set">
            <div class="col-md-12">
              <?php $__currentLoopData = $footer_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <h2><?php echo e($footer_1->title); ?></h2>

                <hr class="sub-hr" />
                <?php echo $footer_1->body; ?> 
            </div>
        </div>
        <div class="row">

            <div class="col-md-12 text-center">


                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                Desarrollado por: <a href="http://www.vgtechnology.com.ve" target="_blank" style="color: #fff; font-size: 12px;">VG TECHNOLOGY C.A</a> Para: <a href="http://asiviajo.com" style="color: #fff; font-size: 12px;">Asiviajo.com</a>
            </div>
        </div>

    </div>
</footer>
