<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/png" href="themes/favicon.png" />

    <link rel="stylesheet" href="<?php echo e(Theme::asset('Optimus::css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Optimus::css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Optimus::css/custom-fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Optimus::css/flexslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Optimus::css/style.css')); ?>">

  </head>
  <body>

  <div id="wrapper" class="home-page">
    <?php $__env->startSection('nav'); ?>
      <?php echo $__env->make('Optimus::partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php $__env->startSection('footer'); ?>
      <?php echo $__env->make('Optimus::partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
  </div>
    <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

    <script src="<?php echo e(Theme::asset('Optimus::js/jquery.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Optimus::js/jquery.easing.1.3.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Optimus::js/bootstrap.min.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Optimus::js/jquery.flexslider.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Optimus::js/animate.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Optimus::js/main.js')); ?>" charset="utf-8"></script>

  </body>
</html>
