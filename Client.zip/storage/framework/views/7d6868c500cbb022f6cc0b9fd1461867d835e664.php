<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Default Theme</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::asset('themes/default/css/materialize.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('themes/default/css/style.css')); ?>">
  </head>
  <body>
    <?php $__env->startSection('header'); ?>
      <?php echo $__env->make('themes.default.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->yieldContent('content'); ?>


    <?php $__env->startSection('footer'); ?>
      <?php echo $__env->make('themes.default.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>


<script src="https://code.jquery.com/jquery-2.2.4.min.js"  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="<?php echo e(URL::asset('themes/default/js/materialize.min.js')); ?>" charset="utf-8"></script>
<script src="<?php echo e(URL::asset('themes/default/js/main.js')); ?>" charset="utf-8"></script>
  </body>
</html>
