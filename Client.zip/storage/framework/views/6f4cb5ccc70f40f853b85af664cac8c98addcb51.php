<?php $__env->startSection('title', 'Index'); ?>
<?php $__env->startSection('content'); ?>

<div id="banner" class="banner">
  <div class="banner-image"></div>
  <div class="banner-caption">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 object-non-visible" data-animation-effect="fadeIn">
          <h1 class="text-center">Lorem <span>Ipsum</span></h1>
          <p class="lead text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos debitis provident nulla illum minus enim praesentium repellendus ullam cupiditate reiciendis optio voluptatem, recusandae nobis quis aperiam, sapiente libero ut at.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<section>
  <div class="section clearfix">
  <div class="container">
    <div class="row">
      <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <div class="col-sm-6 col-md-3 isotope-item web-design">
        <div class="image-box">
          <div class="overlay-container">
            <a href="<?php echo e(route('blog.show', ['id' => $post->id ])); ?>"><img src="../assets/img/<?php echo e($post->post_image); ?>" class="img-responsive"></a>
          </div>
          <a id="blog-button" class="btn btn-default btn-block" href="<?php echo e(route('blog.show', ['id' => $post->id])); ?>"><?php echo e($post->PostTitle); ?></a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
  </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Inspire::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>