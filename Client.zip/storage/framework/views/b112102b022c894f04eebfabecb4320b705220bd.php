<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('body-content'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>