<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="icon" type="image/png" href="themes/favicon.png" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Light::css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Light::css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(Theme::asset('Clean_Light::css/style.css')); ?>">

  </head>
  <body>

    <?php $__env->startSection('nav'); ?>
      <?php echo $__env->make('Clean_Light::partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php $__env->startSection('header'); ?>
      <?php echo $__env->make('Clean_Light::partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php $__env->startSection('footer'); ?>
      <?php echo $__env->make('Clean_Light::partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldSection(); ?>


    <script src="<?php echo e(Theme::asset('Clean_Light::js/jquery-1.11.1.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Light::js/bootstrap.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Light::js/jquery.nicescroll.min.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Light::js/jquery.easing.min.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(Theme::asset('Clean_Light::js/main.js')); ?>" charset="utf-8"></script>

  </body>
</html>
