<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('content'); ?>

<section>
  <div class="container">
    <div class="row">
          <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-sm-12 scrollclass">
        <div class="col-sm-2 blog-img">
          <a href="<?php echo e(route('blog.show', ['id' => $post->id])); ?>"><img src="../assets/img/<?php echo e($post->post_image); ?>" class="img-responsive"></a>
        </div>
        <div class="col-sm-10">
          <a href="<?php echo e(route('blog.show', ['id' => $post->id])); ?>"><h1><?php echo e($post->PostTitle); ?></h1></a>
          <?php echo str_limit($post->post); ?>

        </div>

      </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-sm-12">
        <?php echo $block->render(); ?>

        </div>

    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Clean_Light::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>