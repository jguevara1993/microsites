<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">

        <!-- Styles -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

        <link rel="stylesheet" href="https://cdn.plyr.io/1.5.18/plyr.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('/filemanager_assets/vendor/dmuploader/css/uploader.css')); ?>">
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('/filemanager_assets/css/filemanager.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.0.0/pnotify.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.0.0/pnotify.brighttheme.min.css">

        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('/filemanager_assets/vendor/contextMenu/dist/jquery.contextMenu.css')); ?>">
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('/filemanager_assets/vendor/highlight/styles/agate.css')); ?>">
        

        <?php if( view()->exists('vendor.infinety.filemanager.modals') ): ?>
            <?php echo $__env->make('vendor.infinety.filemanager.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('filemanager::modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </head>
    <body>
        <div class="default-views default-dialog">
            <div class="panel panel-default customnav">
                <div class="panel-heading customnav">
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <ul class="nav navbar-nav">
                                <div class="upload_div hide">
                                    <input type="file" name="files[]" id="single-upload-file" multiple="multiple" title="Click to add Files">
                                </div>
                                <li><button class="btn btn-info btn-cons" id="single-upload"<i class="fa fa-upload"></i> Upload</button></li>
                                <li><button class="btn btn-info btn-cons" data-toggle="modal" data-target="#modalCreateFolder"><i class="fa fa-folder"></i> Create Folder</button></li>
                                <li class="home"><button class="btn btn-default"><i class="fa fa-home"></i></button></li>
                                <li class="refresh"><button class="btn btn-default"><i class="fa fa-refresh"></i></button></li>
                                <li class="move hide"><button class="btn btn-default"><i class="fa fa-arrows"></i> Move</button></li>
                                <li class="delete hide"><button class="btn btn-default"><i class="fa fa-trash"></i> Delete</button></li>
                                <li class="preview hide"><button class="btn btn-default"><i class="fa fa-eye"></i> Preview</button></li>
                                <li class="find">
                                    <div class="navbar-form navbar-left navbar-input-group">
                                        <div class="input-group form-search">
                                            <input type="text" class="form-control search-input" id="search" placeholder="&#61442; Search">
                                            <span class="input-group-addon input-group-search">
                                                <button class="btn btn-info" id="search-button" type="button"><i class="fa fa-search" aria-hidden="false"></i></button>
                                                <button class="btn btn-info hide" id="reset-button" type="button"><i class="fa fa-times" aria-hidden="false"></i></button>
                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <form class="navbar-form navbar-right hide" role="search">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                    </div>
                                    <button type="submit" class="btn btn-default">Submit</button>
                                </form>
                                <ul class="nav navbar-nav navbar-right views">
                                    <li class="list view-type"><button class="btn btn-default"><i class="fa fa-th-list"></i></button></li>
                                    <li class="grid view-type active"><button class="btn btn-default"><i class="fa fa-th"></i></button></li>
                                    <li class="big-grid view-type"><button class="btn btn-default"><i class="fa fa-th-large"></i></button></li>
                                </ul>

                                <ul class="nav navbar-nav navbar-right">

                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav>
                </div>
                <div class="panel-body" >
                    <div class="row">
                        
                        
                        <div class="col-md-12">
                            <ol class="breadcrumb">
                                <?php $home = explode('/', config('filemanager.homePath')); ?>
                                <li class="active" data-folder="Home"><a href="#"><?php echo e(last($home)); ?></a></li>
                            </ol>
                        </div>
                    </div>
                    
                        
                        
                            
                            
                            
                            
                            
                        
                        
                        
                            
                            
                            
                        
                    
                    
                    <div class="col-xs-12">
                        <div class="col-xs-12">
                            <div class="row upload_div" id="files_container">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

         <!-- JavaScripts -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
        

        <script src="https://cdn.plyr.io/1.5.18/plyr.js" type="text/javascript"></script>
        <script src="<?php echo e(asset('/filemanager_assets/vendor/pdfobject.js')); ?>" type="text/javascript"></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery.fileDownload/1.4.2/jquery.fileDownload.min.js'></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.0.0/pnotify.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pnotify/3.0.0/pnotify.buttons.min.js" type="text/javascript"></script>
        <script src="<?php echo e(asset('/filemanager_assets/vendor/contextMenu/dist/jquery.contextMenu.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/filemanager_assets/vendor/contextMenu/dist/jquery.ui.position.min.js')); ?>" type="text/javascript"></script>

        <script src="<?php echo e(asset('/filemanager_assets/vendor/highlight/highlight.pack.js')); ?>" type="text/javascript"></script>

        <script src="<?php echo e(asset('/filemanager_assets/vendor/dmuploader/js/dmuploader.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/filemanager_assets/vendor/dmuploader/js/gallery.js')); ?>" type="text/javascript"></script>


        <script>
            (function(d, p){
                var a = new XMLHttpRequest(),
                        b = d.body;
                a.open('GET', p, true);
                a.send();
                a.onload = function() {
                    var c = d.createElement('div');
                    c.setAttribute('hidden', '');
                    c.innerHTML = a.responseText;
                    b.insertBefore(c, b.childNodes[0]);
                };
            })(document, 'https://cdn.plyr.io/1.5.18/sprite.svg');

        </script>
        <script>
            $(document).ready(function(){
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                /**
                 * Set global variables
                 */

                url_process = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/get_folder')); ?>";
                url_upload  = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/uploadFile')); ?>";
                url_cfolder = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/createFolder')); ?>";
                url_delete  = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/delete')); ?>";
                url_download = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/download')); ?>";
                url_preview  = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/preview')); ?>";
                url_move  = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/move')); ?>";
                url_rename  = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/rename')); ?>";
                url_optimize  = "<?php echo e(url(config('filemanager.defaultRoute', 'admin/filemanager').'/optimize')); ?>";
                optimizeOption = <?php echo e((config('filemanager.optimizeImages', false)) == 1 ? 'true' : 'false'); ?>;
                image_path  = "<?php echo e(asset('/')); ?>";
                homeFolder  = "<?php echo e(last($home)); ?>";
                path_folder = "";
                current_file = null;
                cutted_file = null;
                temp_folder = null;
                globalFilter = "<?php echo e((isset($_GET['filter'])) ? $_GET['filter'] : 'image'); ?>";
                typeCallback = "<?php echo e((isset($_GET['type'])) ? $_GET['type'] : 'featured'); ?>";
                editorId =  "<?php echo e((isset($_GET['editor'])) ? $_GET['editor'] : null); ?>";
                /**
                 * Languages variables
                 */

                text_upload = "<?php echo trans('kgallery.upload.info'); ?>";


            });
        </script>
        <script src="<?php echo e(asset('filemanager_assets/js/filemanager.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('filemanager_assets/js/upload.js')); ?>" type="text/javascript"></script>
    </body>
</html>