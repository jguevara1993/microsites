<?php $__env->startSection('title', 'Asiviajo.com'); ?>
<?php $__env->startSection('content'); ?>

<section class="content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xs-12">
        <h1>Editar Entrada <?php echo e($post->id); ?></h1>
        <p>Aqui puedes editar tus entradas que seran mostradas en la pagina de blog</p>

      </div>
      <div class="col-xs-8">
        <form class="form-horizontal" action="<?php echo e(route('blog.update', ['id' => $post->id])); ?>" method="POST" enctype="multipart/form-data">

          <div class="form-group">
            <label for="PostTitle" class="col-sm-2 control-label">Titulo: </label>
            <div class="col-sm-10">
            <input type="text" name="PostTitle" id="PostTitle"  class="form-control" placeholder="Titulo del post..." value="<?php echo e($post->PostTitle); ?>">
          </div>
          </div>
          <input type="hidden" name="editForm" value="editForm">
          <div class="form-group">
            <div class="col-sm-12">
            <textarea name="post" rows="8" id="post" cols="80" class="form-control"> <?php echo e($post->post); ?></textarea>
          </div>
          </div>
          <div class="col-sm-12">
            <button type="submit" class="btn btn-success" name="buttonSubmit">Editar</button>
            <a class="btn btn-warning" href="<?php echo e(route('blog.index')); ?>" role="button">Cancelar</a>

          </div>
      </div>
        <div class="col-xs-4">
          <div class="post-panel">
        </div>
        <div class="post-panel-2">
          <table class="table table-bordered">
            <tr>
              <th>Estatus: </th>
              <td>Activo</td>
            </tr>
            <tr>
              <th>Fecha de creacion: </th>
              <td><?php echo e($post->created_at->format('d-m-Y H:i:s')); ?></td>
            </tr>
          </table>
        </div>
        <div class="post-panel-3">
            <div class="form-group" >
              <label for="tagsEdit">Etiquetas: </label>
              <input type="text" name="tags[]" value="<?php foreach($post->tags as $tag){echo $tag->tag;}?>" data-role="tagsinput">
              </div>
                <div class="form-group">
              <label>Categoria: </label>
              <div class="multiselect">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                  <label><?php echo e(Form::checkbox('categories[]', $category->id, $post->categories->contains($category->id) ? true : false)); ?> <?php echo e($category->category_name); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </div>
            </div>
          <div class="form-group">
            <label for="postImage">Imagen Destacada: </label>
            <input type="file" name="postImage" id="postImage" onchange="document.getElementById('imgThumbnail').src = window.URL.createObjectURL(this.files[0]);">
            <p class="help-block">Imagen que aparecera al principio del post.</p>
          <div class="imgThumbnail">
            <img id="imgThumbnail" src="../../../assets/img/<?php echo e($post->post_image); ?>" class="img-responsive" />
          </div>
        </div>
            <input type="hidden" name="_method" value="PUT">
            <?php echo e(csrf_field()); ?>

          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>