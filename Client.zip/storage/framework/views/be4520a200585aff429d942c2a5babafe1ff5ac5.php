
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						<div class="col-md-3">
							<?php $__currentLoopData = $footer_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		            <h3><?php echo e($footer_1->title); ?></h3>
		            <?php echo $footer_1->body; ?>

		            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</div>

						<div class="col-md-3 col-md-push-1">
							<?php $__currentLoopData = $footer_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		            <h3><?php echo e($footer_2->title); ?></h3>
		            <?php echo $footer_2->body; ?>

		            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</div>

						<div class="col-md-3 col-md-push-1">
							<?php $__currentLoopData = $footer_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_3): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		            <h3><?php echo e($footer_3->title); ?></h3>
		            <?php echo $footer_3->body; ?>

		            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</div>
						<div class="col-md-3">
							<?php $__currentLoopData = $footer_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_4): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		            <h3><?php echo e($footer_4->title); ?></h3>
		            <?php echo $footer_4->body; ?>

		            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<p class="fh5co-social-icons">
								<?php $__currentLoopData = $face; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $face): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<a href="https://facebook.com/<?php echo e($face->value); ?>"><i class="icon-facebook"></i></a>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	              <?php $__currentLoopData = $twit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twit): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	              <a href="https://twitter.com/<?php echo e($twit->value); ?>"><i class="icon-twitter"></i></a>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	              <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<a href="https://linkedin.com/<?php echo e($link->value); ?>"><i class="icon-linkedin"></i></a>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	              <?php $__currentLoopData = $inst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<a href="https://instagram.com/<?php echo e($inst->value); ?>"><i class="icon-instagram"></i></a>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

							</p>
							<p>&copy <?php echo date('Y') ?> Desarrollado por: <a href="http://vgtechnology.com.ve/" target="_blank">VG TECHNOLOGY</a> Para: <a href="http://asiviajo.com/" target="_blank">Asiviajo.com</a> </p>
						</div>
					</div>
				</div>
			</div>
		</footer>
