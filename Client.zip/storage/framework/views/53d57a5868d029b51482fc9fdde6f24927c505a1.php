<?php $__env->startSection('title', 'Index'); ?>
<?php $__env->startSection('content'); ?>

<section id="main-slider" class="no-margin">
    <div class="carousel slide">
        <div class="carousel-inner">
            <div class="item active" style="background-image: url(../themes/Basica/assets/images/slides/1.jpg)">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="carousel-content centered">
                                <h2 class="animation animated-item-1">Lorem ipsum dolor sit amet, consectetur adipisicing elit</h2>
                                <p class="animation animated-item-2">Sed mattis enim in nulla blandit tincidunt. Phasellus vel sem convallis, mattis est id, interdum augue. Integer luctus massa in arcu euismod venenatis. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
    </div><!--/.carousel-->
</section><!--/#main-slider-->

<div class="section">
 <div class="container">
  <div class="row">
    <div class="col-sm-12">
      <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <h1><?php echo e($block->title); ?></h1>
      <p><?php echo $block->body; ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Basica::layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>