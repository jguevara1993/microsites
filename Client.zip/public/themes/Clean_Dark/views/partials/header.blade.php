<div id="home-sec">
    <div class="overlay">
        <div class="container">
            <div class="col-md-8 pad-top scrollclass">
            </div>

        </div>
    </div>

</div>
