<div class="navbar navbar-inverse navbar-fixed-top scrollclass">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/">{{ config('app.name')}} </a>
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">Inicio</a></li>
                <li><a href="/about">Quienes somos</a></li>
                <li><a href="/promo">Paquetes</a></li>
                <li><a href="/blog">Blog</a></li>
                <li><a href="/contact">Contacto</a></li>
            </ul>
        </div>

    </div>
</div>
