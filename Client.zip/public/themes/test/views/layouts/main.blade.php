<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="themes/favicon.png" />
    <title>@yield('title') - Default Theme</title>
  </head>
  <body>
    @yield('content')
  </body>
</html>
