<header id="fh5co-header-section" class="sticky-banner">
  <div class="container">
    <div class="nav-header">
      <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
      <h1 id="fh5co-logo"><a href="index.html"><i class="icon-home"></i>{{ config('app.name')}}</a></h1>
      <!-- START #fh5co-menu-wrap -->
      <nav id="fh5co-menu-wrap" role="navigation">
        <ul class="sf-menu" id="fh5co-primary-menu">
          <li><a href="/">Inicio</a></li>
          <li><a href="/about">Sobre nosotros</a></li>
          <li><a href="/promo">Paquetes</a></li>
          <li><a href="/blog">Blog</a></li>
          <li><a href="/contact">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </div>
</header>
